package com.hsbc.codechallenge;

public enum TradeSide {
	BID, ASK
}
